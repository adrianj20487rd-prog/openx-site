openX 1.0 - Windows x64
=======================

1. Drop your Xeno.dll next to openX.host.exe, or click the core chip
   in the sidebar to locate it.
2. Double-click openX.exe.

openX.exe is a native launcher. It checks for .NET Framework 4.7.2 and
installs it from Microsoft if it is missing, then starts openX.host.exe.

The core (Xeno.dll) is NOT included. It is closed source and not
redistributed here.

FOLDERS
  scripts\    *.lua and *.txt appear in the sidebar
  autoexec\   every .lua runs once per client, right after injection

EDITOR
  Tabs on top are open documents.
  F2 or double-click a tab   rename (renames the file too)
  Ctrl+N                     new tab
  Ctrl+O                     open a script
  Ctrl+S                     save
  Ctrl+Shift+S               save as
  Ctrl+W                     close tab
  Ctrl+Tab / Ctrl+Shift+Tab   cycle tabs
  F5                         execute

The docked console shows load, attach, setup, autoexec and execute events.
Hide it with the button in the bottom bar (Ctrl+L clears it).

Executing scripts in Roblox violates the Roblox Terms of Service.
