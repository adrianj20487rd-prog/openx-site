Drop .lua files in this folder.
openX runs each one, in filename order, once per client after injection.
Toggle this with "run autoexec/ after inject" in the sidebar.
