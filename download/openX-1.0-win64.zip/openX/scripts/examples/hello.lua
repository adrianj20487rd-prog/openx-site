print("hello from openX")

local Players = game:GetService("Players")
local me = Players.LocalPlayer
print("local player:", me and me.Name or "unknown")
